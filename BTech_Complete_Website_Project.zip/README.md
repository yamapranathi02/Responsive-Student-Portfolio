# Nova — Student Portfolio Website

A responsive portfolio website built with plain HTML, CSS, and JavaScript, suitable as a B.Tech CSE mini-project starting point.

## Features
- Responsive layout for mobile, tablet, and desktop
- Sticky navigation and mobile menu
- Light/dark theme toggle
- Project showcase cards
- Contact form with browser validation and demo feedback
- Accessible labels, keyboard-focus styles, and reduced-motion support

## Requirements
A modern web browser. No build tools or packages are required.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in Chrome, Firefox, Edge, or another modern browser.
3. Edit the text in `index.html` to personalize your name, skills, projects, and contact information.

Optional: use the VS Code Live Server extension to preview changes while editing.

## Important note
The contact form is front-end only. It validates inputs and displays a demo success message; it does not send an email or save data. For a production version, connect a secure backend or form service.

## Files
- `index.html` — page structure and content
- `style.css` — design, responsive layout, and themes
- `script.js` — menu, theme toggle, and form interaction
- `Project_Report.docx` — editable project report
