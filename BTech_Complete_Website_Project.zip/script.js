const menuToggle = document.querySelector("#menuToggle");
const navLinks = document.querySelector("#navLinks");
const themeToggle = document.querySelector("#themeToggle");
const contactForm = document.querySelector("#contactForm");
const formStatus = document.querySelector("#formStatus");

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "✕" : "☰";
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});

themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("light");
  const lightMode = document.body.classList.contains("light");
  themeToggle.setAttribute("aria-label", lightMode ? "Switch to dark mode" : "Switch to light mode");
  themeToggle.textContent = lightMode ? "☼" : "◐";
});

contactForm.addEventListener("submit", (event) => {
  event.preventDefault();
  if (!contactForm.reportValidity()) return;

  const name = document.querySelector("#name").value.trim();
  formStatus.textContent = `Thanks, ${name}! Your demo message passed validation. Connect a backend to deliver messages.`;
  contactForm.reset();
});
